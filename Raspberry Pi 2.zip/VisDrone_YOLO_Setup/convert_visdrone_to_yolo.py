import os
import shutil

source_img_dir = r"D:\WKU\2025SPRING\capstone2\conference\VisDrone2019-DET-train\images"
source_ann_dir = r"D:\WKU\2025SPRING\capstone2\conference\VisDrone2019-DET-train\annotations"

target_img_dir = r"D:\WKU\2025SPRING\capstone2\conference\dataset\images\train"
target_label_dir = r"D:\WKU\2025SPRING\capstone2\conference\dataset\labels\train"

os.makedirs(target_img_dir, exist_ok=True)
os.makedirs(target_label_dir, exist_ok=True)

valid_classes = [0, 1, 2, 3, 4, 5, 6, 7, 8]
class_map = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    5: 5,
    6: 6,
    7: 7,
    8: 8,
}

for ann_file in os.listdir(source_ann_dir):
    if ann_file.endswith('.txt'):
        img_name = ann_file.replace('.txt', '.jpg')
        src_img_path = os.path.join(source_img_dir, img_name)
        tgt_img_path = os.path.join(target_img_dir, img_name)

        if os.path.exists(src_img_path):
            shutil.copy(src_img_path, tgt_img_path)

        src_ann_path = os.path.join(source_ann_dir, ann_file)
        tgt_label_path = os.path.join(target_label_dir, ann_file)

        with open(src_ann_path, 'r') as f_in, open(tgt_label_path, 'w') as f_out:
            lines = f_in.readlines()
            for line in lines:
                parts = line.strip().split(',')
                x, y, w, h = map(float, parts[0:4])
                cls = int(parts[5])

                if cls not in valid_classes:
                    continue

                img_width = 960
                img_height = 540

                x_center = (x + w / 2) / img_width
                y_center = (y + h / 2) / img_height
                w_norm = w / img_width
                h_norm = h / img_height

                f_out.write(f"{class_map[cls]} {x_center:.6f} {y_center:.6f} {w_norm:.6f} {h_norm:.6f}\n")

print("✅ 转换完成，YOLO格式已生成！")
